# Flex browser

A small, hackable browser created with JS and Electron.

Development builds will be available soon

To download a release please go to http://www.cognizantsoftwaresolutions.ca/flex

# Credits

Demetry Romanowski, Lead Developer Cognizant Software Solutions
demetryromanowski@gmail.com
