//TODO(Demetry): Refactor code to use this class, return global.
